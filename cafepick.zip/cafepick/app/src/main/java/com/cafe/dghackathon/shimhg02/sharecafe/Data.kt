package com.cafe.dghackathon.shimhg02.dghack

class Data(val id: String, val writer: String, val content: String, val date: String)