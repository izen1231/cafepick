package com.cafe.dghackathon.shimhg02.dghack


class HistoryData (val bikeCode : String, val rentHistSeq : String, val rentStart : Rent, val rentEnd : Rent)

class Rent (val time : String, val place : String)
