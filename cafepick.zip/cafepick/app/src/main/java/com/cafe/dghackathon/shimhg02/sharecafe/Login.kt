package com.cafe.dghackathon.shimhg02.dghack


class Login(var success : Boolean?, var session : String?)