package com.cafe.dghackathon.shimhg02.dghack


import com.google.gson.annotations.SerializedName
/**
 * Created by sdie3 on 2018-10-29.
 */
class RackData {
    @SerializedName("rackId")
    var rackId = ""
    @SerializedName("rackNum")
    var rackNum = 0
    @SerializedName("linked")
    var linked = false
}