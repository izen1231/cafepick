package com.cafe.dghackathon.shimhg02.dghack

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.SlidingDrawer
import com.cafe.dghackathon.shimhg02.sharecafe.R


class SlidingdrawerActivity : Activity() {

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sliding)
    }
}